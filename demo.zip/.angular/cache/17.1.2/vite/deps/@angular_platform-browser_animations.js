import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-EORTHML3.js";
import "./chunk-2WKUTDWD.js";
import "./chunk-CEKBGOGA.js";
import "./chunk-PFGETJBS.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-R56XHVEB.js";
import "./chunk-J4B6MK7R.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
