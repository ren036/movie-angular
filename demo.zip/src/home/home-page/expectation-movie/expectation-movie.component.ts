import { Component } from '@angular/core';

@Component({
  selector: 'app-expectation-movie',
  standalone: true,
  imports: [],
  templateUrl: './expectation-movie.component.html',
  styleUrl: './expectation-movie.component.scss'
})
export class ExpectationMovieComponent {

}
