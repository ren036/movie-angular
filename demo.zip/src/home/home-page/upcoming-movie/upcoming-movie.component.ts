import { Component } from '@angular/core';

@Component({
  selector: 'app-upcoming-movie',
  standalone: true,
  imports: [],
  templateUrl: './upcoming-movie.component.html',
  styleUrl: './upcoming-movie.component.scss'
})
export class UpcomingMovieComponent {

}
