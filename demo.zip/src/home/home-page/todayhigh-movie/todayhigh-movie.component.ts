import { Component } from '@angular/core';

@Component({
  selector: 'app-todayhigh-movie',
  standalone: true,
  imports: [],
  templateUrl: './todayhigh-movie.component.html',
  styleUrl: './todayhigh-movie.component.scss'
})
export class TodayhighMovieComponent {

}
