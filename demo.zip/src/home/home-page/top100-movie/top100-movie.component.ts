import { Component } from '@angular/core';

@Component({
  selector: 'app-top100-movie',
  standalone: true,
  imports: [],
  templateUrl: './top100-movie.component.html',
  styleUrl: './top100-movie.component.scss'
})
export class Top100MovieComponent {

}
