import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Top100MovieComponent } from './top100-movie.component';

describe('Top100MovieComponent', () => {
  let component: Top100MovieComponent;
  let fixture: ComponentFixture<Top100MovieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Top100MovieComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Top100MovieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
