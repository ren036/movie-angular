import { Component } from '@angular/core';

@Component({
  selector: 'app-now-movie',
  standalone: true,
  imports: [],
  templateUrl: './now-movie.component.html',
  styleUrl: './now-movie.component.scss'
})
export class NowMovieComponent {

}
