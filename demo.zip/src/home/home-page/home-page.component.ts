import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NowMovieComponent } from "./now-movie/now-movie.component";
import { UpcomingMovieComponent } from "./upcoming-movie/upcoming-movie.component";
import { TodayhighMovieComponent } from "./todayhigh-movie/todayhigh-movie.component";
import { ExpectationMovieComponent } from "./expectation-movie/expectation-movie.component";
import { Top100MovieComponent } from "./top100-movie/top100-movie.component";
@Component({
    selector: 'app-home-page',
    standalone: true,
    templateUrl: './home-page.component.html',
    styleUrl: './home-page.component.scss',
    imports: [RouterModule, NowMovieComponent, UpcomingMovieComponent, TodayhighMovieComponent, ExpectationMovieComponent, Top100MovieComponent]
})
export class HomePageComponent {

}
