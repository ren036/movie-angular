import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import{NzMenuModule} from "ng-zorro-antd/menu"
@Component({
  selector: 'app-mean',
  standalone: true,
  imports: [RouterModule,NzMenuModule],
  templateUrl: './mean.component.html',
  styleUrl: './mean.component.scss'
})
export class MeanComponent {

}
