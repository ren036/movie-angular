import { Routes } from '@angular/router';
import { MeanComponent } from '../home/mean/mean.component';
import { HomePageComponent } from '../home/home-page/home-page.component';

export const routes: Routes = [
    {
        path:"",
        component:MeanComponent,
        children:[
            {
                path:'homepage',
                component:HomePageComponent
            }
        
        ]
    },
];
